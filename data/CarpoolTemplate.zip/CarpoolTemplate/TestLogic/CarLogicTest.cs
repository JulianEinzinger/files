﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestLogic {

    [TestClass]
    public class CarLogicTest {

        [TestMethod]
        public void _01_ConstructorTest() {
            DateTime d = DateTime.Now;
            Car c = new Car(Color.Blue, d, 170);
            Assert.IsNotNull(c, "Konstruktor hat nicht funktioniert!");
            Assert.AreEqual(d, c.DeliveryDate, "Falsches Auslieferungsdatum!");
            Assert.AreEqual(Color.Blue, c.Color, "Falsche Farbe!");
            Assert.AreEqual(170, c.MaxSpeed, "Falsche Maximalgeschwindigkeit!");
            Assert.IsFalse(c.IsDriving, "Das Auto sollte standardmäßig gestoppt sein!");
            Assert.AreEqual(0, c.MinutesDriven, "Das Auto sollte standardmäßig ungefahren sein!");
            Assert.IsFalse(c.AreDoorsOpen, "Die Türen sollte standardmäßig geschlossen sein!");
        }

        [TestMethod]
        public void _02_AgeTest() {
            DateTime d = new DateTime(2020, 1, 1);
            Car c = new Car(Color.Blue, d, 170);
            int expected = (int) ((DateTime.Now - d).TotalDays / 365);
            Assert.AreEqual(expected, c.Age, $"Alter sollte {expected} sein!");
        }

        [TestMethod]
        public void _03_DrivingReturnValueTest() {
            Car c = new Car(Color.Blue, DateTime.Now, 170);
            bool result = c.StartDriving();
            Assert.IsTrue(result, "Auto müsste losfahren können!");
            result = c.StartDriving();
            Assert.IsFalse(result, "Auto fährt schon!");
            Assert.IsTrue(c.IsDriving, "Auto fährt gerade!");
            result = c.StopDriving();
            Assert.IsTrue(result, "Auto müsste stehen bleiben können!");
            result = c.StopDriving();
            Assert.IsFalse(result, "Auto steht schon!");
            Assert.IsFalse(c.IsDriving, "Auto steht gerade!");
        }

        [TestMethod]
        public void _04_DrivingTimeTest() {
            Car c = new Car(Color.Blue, DateTime.Now, 170);
            c.StartDriving();
            Thread.Sleep(3000);
            c.StopDriving();
            Assert.AreEqual(0.05, c.MinutesDriven, .01, "Auto ist genau 3 Sekunden gefahren!");
        }

        [TestMethod]
        public void _05_ToStringTest() {
            Car c = new Car(Color.Blue, DateTime.Now, 170);
            Assert.AreEqual("Ich bin ein blaues Auto und ich kann bis zu 170 km/h schnell fahren!", c.ToString(), "ToString() Text ist nicht korrekt!");
        }

        [TestMethod] 
        public void _06_GetTypeTest() {
            Car c = new Car(Color.Blue, DateTime.Now, 170);
            Assert.AreEqual("Auto", c.GetType(), "GetType Text ist nicht korrekt!");
        }

        [TestMethod]
        public void _07_DoorTest() {
            Car c = new Car(Color.Blue, DateTime.Now, 170);
            bool result = c.CloseDoors();
            Assert.IsFalse(result, "Türen sind schon zu!");
            result = c.OpenDoors();
            Assert.IsTrue(result, "Türen sollten auf gehen!");
            Assert.IsTrue(c.AreDoorsOpen, "Türen sind geöffnet!");
            result = c.OpenDoors();
            Assert.IsFalse(result, "Türen sind schon offen!");
            result = c.CloseDoors();
            Assert.IsTrue(result, "Türen sollten zu gehen!");
            Assert.IsFalse(c.AreDoorsOpen, "Türen sind geschlossen!");
        }
    }
}
