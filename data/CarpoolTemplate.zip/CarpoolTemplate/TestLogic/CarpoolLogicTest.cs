﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestLogic {

    [TestClass]
    public class CarpoolLogicTest {

        [TestMethod]
        public void _01_CountTest() {
            Carpool c = new Carpool();
            Assert.AreEqual(0, c.Count, "Count muss am Anfang mit 0 initialisiert werden!");

            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            Car v2 = new Car(Color.Green, d, 90);
            c.AddVehicle(v1);
            c.AddVehicle(v2);
            Assert.AreEqual(2, c.Count, "Count sollte 2 sein!");
        }

        [TestMethod]
        public void _02_AddVehicleSizeTest() {
            Carpool c = new Carpool();
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);

            bool result;
            int counter = 0;
            do {
                result = c.AddVehicle(v1);
                counter++;
            } while (result);

            Assert.AreEqual(50, counter, "In die Garage sollten exakt 50 Fahrzeuge passen!");
        }

        [TestMethod]
        public void _03_AddVehicleNullReferenceTest() {
            Carpool c = new Carpool();
            bool result = c.AddVehicle(null);

            Assert.IsFalse(result, "Null ist kein gültiges Fahrzeug!");
        }

        [TestMethod]
        public void _04_AddVehicleAtSpotInvalidArgumentTest() {
            Carpool c = new Carpool();
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            bool result = c.AddVehicleAtSpot(v1, 0, 4);
            Assert.IsFalse(result, "0 ist ein ungültiges Stockwerk!");
            result = c.AddVehicleAtSpot(v1, 3, 11);
            Assert.IsFalse(result, "11 ist ein ungültiger Parkplatz!");
            result = c.AddVehicleAtSpot(null, 4, 4);
            Assert.IsFalse(result, "Null ist kein gültiges Fahrzeug!");
        }

        [TestMethod]
        public void _05_AddVehicleAtSpotReturnValueTest() {
            Carpool c = new Carpool();
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Black, d, 100);
            Car v2 = new Car(Color.Yellow, d, 100);
            c.AddVehicleAtSpot(v1, 2, 2);
            bool result = c.AddVehicleAtSpot(v2, 2, 2);

            Assert.IsFalse(result, "Ein Fahrzeug kann nicht auf einen Platz gestellt werden, der bereits besetzt ist!");
        }


        [TestMethod]
        public void _06_GetVehicleAtSpotReturnValueTest() {
            Carpool c = new Carpool();
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            Car v2 = new Car(Color.Red, d, 85);
            c.AddVehicleAtSpot(v1, 2, 7);
            c.AddVehicleAtSpot(v2, 4, 10);

            Assert.AreEqual(v1, c.GetVehicleAtSpot(2, 7), "Falsches Fahrzeug gespeichert!");
            Assert.AreEqual(v2, c.GetVehicleAtSpot(4, 10), "Falsches Fahrzeug gespeichert!");
        }

        [TestMethod]
        public void _07_GetVehicleAtSpotInvalidArgumentTest() {
            Carpool c = new Carpool();
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            bool result = c.AddVehicleAtSpot(null, 2, 7);

            Assert.IsFalse(result, "Null ist kein gültiges Fahrzeug!");
            result = c.AddVehicleAtSpot(v1, 10, 2);
            Assert.IsFalse(result, "10 ist ein ungültiges Stockwerk!");
            result = c.AddVehicleAtSpot(v1, 3, -2);
            Assert.IsFalse(result, " -2 ist ein ungültiger Parkplatz!");
        }

        

        [TestMethod]
        public void _08_GetVehiclesOnFloorReturnValueTest() {
            Carpool c = new Carpool();
            Assert.AreEqual(null, c.GetVehicleOnFloor(3)[0], "Parkplätze müssen mit null initialisiert sein!");
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            Car v2 = new Car(Color.Red, d, 85);
            c.AddVehicleAtSpot(v1, 3, 5);
            c.AddVehicleAtSpot(v2, 3, 2);

            Vehicle[] vehicles = c.GetVehiclesOnFloor(3);
            Assert.AreEqual(vehicles[0], v2, "Falsche Referenz auf Stockwerk 3!");
            Assert.AreEqual(vehicles[1], v1, "Falsche Referenz auf Stockwerk 3!");
        }

        [TestMethod]
        public void _09_GetVehiclesOnFloorInvalidArgumentTest() {
            Carpool c = new Carpool();
            Assert.AreEqual(null, c.GetVehicleOnFloor(3)[0], "Parkplatz muss mit null initialisiert sein!");
            DateTime d = new DateTime(year: 2000, month: 1, day: 1);
            Car v1 = new Car(Color.Red, d, 85);
            Vehicle[] result = c.GetVehiclesOnFloor(0);

            Assert.AreEqual(null, result, "0 ist ein ungültiges Stockwerk -> null");
        }
    }
}
