﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestLogic {

    [TestClass]
    public class MotorcycleLogicTest {

        public void _01_ConstructorTest() {
            DateTime d = DateTime.Now;
            Motorcycle m = new Motorcycle(Color.Blue, d, 170);
            Assert.IsNotNull(m, "Konstruktor hat nicht funktioniert!");
            Assert.AreEqual(d, m.DeliveryDate, "Falsches Auslieferungsdatum!");
            Assert.AreEqual(Color.Blue, m.Color, "Falsche Farbe!");
            Assert.AreEqual(170, m.MaxSpeed, "Falsche Maximalgeschwindigkeit!");
            Assert.IsFalse(m.IsDriving, "Das Motorrad sollte standardmäßig gestoppt sein!");
            Assert.AreEqual(0, m.MinutesDriven, "Das Motorrad sollte standardmäßig ungefahren sein!");
            Assert.IsFalse(m.TimesHonked, "Die Hupanzahl sollte mit 0 initialisiert sein!");
        }

        [TestMethod]
        public void _02_AgeTest() {
            DateTime d = new DateTime(2020, 1, 1);
            Motorcycle m = new Motorcycle(Color.Blue, d, 170);
            int expected = (int)((DateTime.Now - d).TotalDays / 365);
            Assert.AreEqual(expected, m.Age, $"Alter sollte {expected} sein!");
        }

        [TestMethod]
        public void _03_DrivingReturnValueTest() {
            Motorcycle m = new Motorcycle(Color.Blue, DateTime.Now, 170);
            bool result = m.StartDriving();
            Assert.IsTrue(result, "Motorrad müsste losfahren können!");
            result = m.StartDriving();
            Assert.IsFalse(result, "Motorrad fährt schon!");
            Assert.IsTrue(m.IsDriving, "Auto fährt gerade!");
            result = m.StopDriving();
            Assert.IsTrue(result, "Motorrad müsste stehen bleiben können!");
            result = m.StopDriving();
            Assert.IsFalse(result, "Motorrad steht schon!");
            Assert.IsFalse(m.IsDriving, "Motorrad steht gerade!");
        }

        [TestMethod]
        public void _04_DrivingTimeTest() {
            Motorcycle m = new Motorcycle(Color.Blue, DateTime.Now, 170);
            m.StartDriving();
            Thread.Sleep(3000);
            m.StopDriving();
            Assert.AreEqual(0.05, m.MinutesDriven, .01, "Motorrad ist genau 3 Sekunden gefahren!");
        }

        [TestMethod]
        public void _05_ToStringTest() {
            Motorcycle m = new Motorcycle(Color.Green, DateTime.Now, 232);
            Assert.AreEqual("Ich bin ein grünes Motorrad und ich kann bis zu 232 km/h schnell fahren!", m.ToString(), "ToString() Text ist nicht korrekt!");
        }

        [TestMethod]
        public void _06_GetTypeTest() {
            Motorcycle m = new Motorcycle(Color.Blue, DateTime.Now, 175);
            Assert.AreEqual("Motorrad", m.GetType(), "GetType Text ist nicht korrekt!");
        }

        [TestMethod]
        public void _07_HonkTest() {
            Motorcycle m = new Motorcycle(Color.Blue, DateTime.Now, 175);
            for (int i = 0; i < 14; i++) {
                m.Honk();
            }
            Assert.AreEqual(14, m.TimesHonked, "Hupanzahl sollte 14 sein!");
        }
    }
}
