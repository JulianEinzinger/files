﻿public enum Color {
    Red,
    Yellow,
    Green,
    Blue,
    Black,
    White,
}